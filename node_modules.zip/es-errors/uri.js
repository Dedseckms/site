'use strict';

/** @type {import('./uri')} */
module.exports = URIError;
